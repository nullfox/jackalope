# `serverless`

> TODO: description

## Usage

```
const serverless = require('serverless');

// TODO: DEMONSTRATE API
```
