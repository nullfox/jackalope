import Serverless from 'serverless';

import {
  inspect,
} from 'util';

import {
  ok,
} from 'assert';

import {
  sync,
} from 'glob';

import {
  chain,
  get,
  has,
  set,
} from 'lodash';

import File from './plugin/file';

const CUSTOM_KEY_PREFIX = 'foxface';

const KEY_CONTEXT = 'context';
const KEY_FUNCTION_SOURCE = 'functionSource';
const KEY_PSEUDO_NAME = 'psuedoName';

const KEY_RPC = 'rpc';
const KEY_RPC_PATH = 'path';
const KEY_RPC_METHODS = 'methods';

export default class Plugin {
  sls: Serverless
  options: Serverless.Options
  hooks: { [key: string]: Function }
  files: Array<File>

  constructor(sls: Serverless, options: Serverless.Options) {
    this.sls = sls;
    this.options = options;

    this.hooks = {
      'before:package:initialize': this.assemble.bind(this),
      'before:package:createDeploymentArtifacts': this.wrap.bind(this),
      'before:deploy:function:packageFunction': this.wrap.bind(this),
      'before:invoke:local:invoke': this.assembleAndWrap.bind(this),
      'before:offline:start': this.assembleAndWrap.bind(this),
    };

    ok(
      this.hasCustomValue(KEY_CONTEXT),
      `${KEY_CONTEXT} key must be set in serverless.yml (ex: custom.${CUSTOM_KEY_PREFIX}.${KEY_CONTEXT}: lib/context`,
    );

    ok(
      this.hasCustomValue(KEY_FUNCTION_SOURCE),
      `${KEY_FUNCTION_SOURCE} key must be set in serverless.yml (ex: custom.${CUSTOM_KEY_PREFIX}.${KEY_FUNCTION_SOURCE}: lib/functions`,
    );

    ok(
      this.hasCustomValue(KEY_PSEUDO_NAME),
      `${KEY_PSEUDO_NAME} key must be set in serverless.yml (ex: custom.${CUSTOM_KEY_PREFIX}.${KEY_PSEUDO_NAME}: FoxFace`,
    );

    const files = sync(`${this.getCustomValue(KEY_FUNCTION_SOURCE)}/**/*.+(js|ts)`);
    
    this.files = chain(files)
      .filter(file => !file.split('/').pop()?.startsWith('_'))
      .map(file => File.factory(file, this))
      .value();
  }

  hasCustomValue(key: string, prefix: string = CUSTOM_KEY_PREFIX): boolean {
    return has(this.sls.service, `custom.${prefix}.${key}`);
  }

  getCustomValue(key: string, prefix: string = CUSTOM_KEY_PREFIX): string {
    return get(this.sls.service, `custom.${prefix}.${key}`);
  }

  assemble(): void {
    const functions = chain(this.files)
      .filter(file => file.shouldRegister())
      .map(file => file.getHandler())
      .keyBy(handler => handler.getKey())
      .mapValues(handler => handler.toServerless())
      .value();

    set(
      this.sls.service,
      'functions',
      {
        ...get(this.sls.service, 'functions', {}),
        ...(functions),
      },
    );

    // @ts-ignore
    console.log('Functions', inspect(this.sls.service.functions, true, null));
  }

  wrap(): void {
    this.files.forEach((file) => {
      file.write();

      if (file.shouldRegister()) {
        set(
          this.sls.service,
          `functions[${file.getHandler().getKey()}].handler`,
          file.getOutputFile()
        );
      }
    });
  }

  assembleAndWrap(): void {
    this.assemble();
    this.wrap();
  }
}

module.exports = Plugin;
