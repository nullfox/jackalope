import {
  join,
} from 'path';

/**
 * @rpc /
 */
export default () => join(__dirname, 'rpc');
