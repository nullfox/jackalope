export default {
  exec: async () => (
    {
      name: 'foooo',
    }
  ),
};
