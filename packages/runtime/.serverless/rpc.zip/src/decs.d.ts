declare module 'docblock'

