declare module '@foxface/runtime'
declare module '@foxface/serverless'