import {
  Context,
} from '@foxface/runtime';

export default Context.factory(
  'test',
  {},
);
