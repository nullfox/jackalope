/**
 * @method
 * @description Coach login via email or username
 * @auth false
 * @param {string.email} email - Coach email address
 */
export default (event: any, context: any) => {
  console.log(context);

  return 'Hello world!';
};
