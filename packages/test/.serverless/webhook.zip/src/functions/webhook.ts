/**
 * @queue #{FoxFace::StageName}-inbound
 * @description Coach login via email or username
 * @auth false
 * @param {number.integer.required} id - Message id
 * @param {string.required} text - Message text ("Im feeling down today :(")
 */
export default (event: any, context: any) => {
  console.log(context);

  return 'Hello world!';
};
